// Copyright Epic Games, Inc. All Rights Reserved.

#include "MPV_Practicas.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, MPV_Practicas, "MPV_Practicas" );
