#pragma once

FVector LerpVector(FVector A, FVector B, double t);
float ConvertTo360(float angle);
float ConvertTo180(float angle);
float Sign(float n);

