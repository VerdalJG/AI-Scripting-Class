-- Escribe tu c�digo

-- Termina tu c�digo
io.read()
